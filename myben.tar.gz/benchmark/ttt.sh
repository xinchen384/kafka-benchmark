
maxNum=1000
a=1234

if (($a > $maxNum))
then
a=$maxNum
fi

echo "a=$a"
echo 'a='"$a"


