

#rm -rf /homes/hny9/chenxin/kafka/logs/server-log/*
#rm -rf /homes/hny9/chenxin/kafka/logs/zk-log/*

rm -rf /tmp/kafka/server-log/*
rm -rf /tmp/kafka/zk-log/*

